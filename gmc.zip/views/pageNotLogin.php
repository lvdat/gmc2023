<div class="col-12">
    <div class="card">
        <div class="card-body text-center">
            <p>
                Bạn chưa đăng nhập. Vui lòng click vào liên kết trong email để tự động đăng nhập vào hệ thống. <br />
                Nếu không nhận được mail, vui lòng kiểm tra thư mục spam, mọi chi tiết liên hệ qua: <br />
                Email: <a href="mailto:<?=$config['email']?>"><?=$config['email']?></a> | Zalo: <a target="_blank" href="https://zalo.me/<?=$config['zalo']?>"><?=$config['zalo']?></a>
            </p>
        </div>
    </div>
</div>
<script>
    document.title = '<?=$config['site_title']?>';
</script>