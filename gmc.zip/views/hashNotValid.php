<div class="col-12">
    <div class="card">
        <div class="card-body text-center">
            <p>
                Mã hash không hợp lệ, đảm bảo bạn đã click đúng liên kết đã gửi qua email!
            </p>
        </div>
    </div>
</div>