## Hệ thống đánh giá xếp loại Đoàn viên
Hệ thống đánh giá xếp loại Đoàn viên được thiết kế riêng cho các Chi Đoàn trực thuộc Đoàn Khoa CNTT&TT.

## Chức năng
- Thống kê số lượng Đoàn viên, thống kê theo xếp hạng,..
- Cho Đoàn viên của Chi đoàn với `URL` tự động
- Tính năng cho phép Đoàn viên xem kết quả học tập, kết quả xếp loại tạm thời của Chi đoàn, kết quả chính thức từ Đoàn Khoa
- Tính năng bình xét Đoàn viên Ưu tú ẩn danh

## Yêu cầu
- Hệ điều hành: Linux, Windows, OSX (Untested)
- MariaDB: latest
- PHP: 7.4.3
- Composer 2

## Cài đặt
Để biết quy trình cài đặt chi tiết, vui lòng liên hệ qua email `lvdat13@gmail.com`